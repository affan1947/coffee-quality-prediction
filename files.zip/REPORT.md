# Coffee Quality Prediction — Findings

**Scope:** exploratory data science engagement on ~1,550 simulated roasting batches.
**Deliverable:** working modelling pipeline, an assessment of what the data can and cannot support, and recommended next steps.

---

## 1. Executive summary

Three findings drive everything below.

1. **A reliable model is technically achievable.** Hold-out R² ranges from 0.84 to 0.99 across the four quality dimensions.
2. **Quality is driven by the process, not the beans.** Green-bean properties alone predict almost nothing (R² ≈ 0). Add the three controllable roast settings and accuracy jumps to 0.87–0.99. This is the commercially useful result: it means quality is *actionable*.
3. **The accuracy numbers will not survive contact with real data.** Each target is explained by two or three variables in a near-deterministic way. That is the signature of simulated data, not of a human sensory panel. The pipeline is validated; the headline R² is not a business forecast.

---

## 2. The data, and what had to be fixed

| Source | Rows | Role |
|---|---|---|
| `batch_reports.csv` | 1,551 | bean properties + roast settings, one row per batch |
| `quality_measurements.csv` | 1,554 | the four expert scores |
| `sensorvalues.csv` | 358,340 | 20 tags × 17,917 timestamps, 1-minute sampling |
| `sensortags.csv` | 20 | tag dictionary with units |

**Cleaning decisions** (all recorded in `CleaningReport`, `src/data_loader.py`):

- **Two batches carry contradictory duplicate labels.** `B-781456` is scored with an Aroma of 86.6 in one row and 5.3 in another; `B-820426` shows 62.8 versus 119.5. Averaging would invent a score no expert gave, so both batches were dropped and the IDs flagged for the plant. *This is the single most important data-quality issue found: it implies the labelling process can produce irreconcilable results, which caps the accuracy any model can honestly claim.*
- **2 batches have no label, 1 label has no batch.** Dropped.
- **`end_ts − start_ts` reproduces `roasting_time` exactly** (r = 1.000). Redundant; one is kept.
- No nulls anywhere. Sensor coverage is complete: every batch window contains 5–18 readings per tag.

**Final modelling set: 1,547 batches.**

### Target distributions differ sharply

![target distributions](figures/01_target_distributions.png)

- **Bitterness** is near-normal (68–101).
- **Body** is left-skewed with a long low tail.
- **Aroma** spans 0.4–194 — a very wide range.
- **Acidity** is severely right-skewed: median 0.08, mean 3.09, max 113.9.

Acidity is therefore modelled on a `log1p` scale (via `TransformedTargetRegressor`, so predictions and metrics stay on the original scale). This alone lifted its cross-validated R² from 0.83 to 0.94 in early testing.

---

## 3. Feature engineering

The sensor stream is 1-minute data; a batch lasts 5–19 minutes. Each batch is matched to its time window by vectorised binary search, and each of the 20 tags is collapsed into five statistics:

**mean, std, min, max, delta** (last reading − first)

`delta` matters because it captures *direction of travel*. A roast where airflow climbs and one where it falls describe different processes but share the same average — a mean-only summary would treat them as identical.

That yields **100 sensor features + 6 batch features**.

### Three feature sets, and why the split matters

This is the central design decision of the project. Sensor data is recorded *during* the roast, so a model that depends on it can only grade a batch after the fact — it cannot plan one.

| Set | Contents | Available when? | Use case |
|---|---|---|---|
| `bean_only` | green-bean properties | at intake | what can this lot become? |
| `planning` | beans + roasting time, temperature setpoint, water mist | **before the roast** | **prescriptive optimisation** |
| `full` | + all 100 sensor aggregates | after the roast | quality control / cupping triage |

---

## 4. Model selection

Four estimators spanning a deliberate complexity gradient, validated by 5-fold CV on the training portion and scored on a **chronological hold-out** (the most recent 20% of batches). A random split would flatter the model by letting it learn from batches that occur *after* the ones it is graded on; production always predicts forward in time.

| Estimator | Purpose |
|---|---|
| `DummyRegressor` | the floor every model must clear |
| `RidgeCV` | interpretable linear baseline |
| `RandomForest` | variance-reduction cross-check |
| `HistGradientBoosting` | non-linear workhorse; no scaling needed, trains in seconds |

### Hold-out results (winning model per target)

| Target | Model | R² | MAE | Target std |
|---|---|---|---|---|
| Aroma | GBM | **0.931** | 8.76 | 45.3 |
| Acidity | GBM | **0.839** | 1.22 | 10.7 |
| Bitterness | Ridge | **0.993** | 0.33 | 5.26 |
| Body | Random Forest | **0.994** | 0.90 | 15.3 |

![predictions](figures/02_predictions.png)

![residuals](figures/03_residuals.png)

Residuals are broadly centred, but Aroma shows mild fanning at high values and Acidity retains structure at the low end even after the log transform — the model under-predicts the rare very-high-acidity batches, which are exactly the off-spec cases the plant would most want to catch.

**Note that Ridge wins Bitterness outright at R² = 0.993.** A regularised linear model beating gradient boosting means Bitterness is essentially a *linear* function of sugar content, moisture and roasting time. That is strong evidence of an underlying generative formula rather than a sensory measurement.

---

## 5. Answers to the questions posed

### 5.1 Is a reliable predictive model possible with this data?

**Technically yes; commercially, treat these numbers as an upper bound.**

The pipeline generalises cleanly to unseen future batches with no tuning heroics. But three observations point to simulated rather than measured data:

- A linear model achieves R² = 0.993 on Bitterness.
- Each target is dominated by two or three features, with the remaining ~100 contributing importances near zero.
- Real expert cupping panels show substantial inter-rater disagreement. Published sensory studies typically find panel reliability well short of the 0.99 achieved here.

The two contradictory duplicate labels are the tell: when the *same batch* is scored twice, the scores disagree wildly. Any real deployment is capped by that label noise, not by model capacity.

**What I would report to the customer:** the method is validated and the data pipeline works end to end. Expect real-world R² substantially below these figures, and budget for measuring label reliability before promising accuracy to anyone.

### 5.2 Which features matter most?

![importances](figures/04_importances.png)

Permutation importance computed on **held-out** data — the question is which features the model relies on to *generalise*, not which it used to memorise the training set.

| Target | Dominant drivers |
|---|---|
| **Aroma** | Roasting temperature (mean), roasting time |
| **Acidity** | Roasting temperature (mean), roasting time |
| **Bitterness** | Sugar content, roasting time, roasting temperature |
| **Body** | Roasting time, water mist |

Two conclusions:

1. **`roasting_time` and `Roasting_Temp` drive all four dimensions.** They are also both controllable. This is the lever the plant has.
2. **Of the 20 sensor tags, only Roasting_Temp carries real signal.** The other 19 — airflow, humidity, vacuum, conveyor speed, chaff, grinder speed and the rest — contribute importances at or near zero. In simulated data this is expected. In a real plant it would be a finding worth acting on: it would suggest either that those sensors are not informative for quality, or that batch-level averaging is discarding the within-roast dynamics that matter.

### 5.3 The most valuable finding: quality is process-driven

![feature set comparison](figures/05_feature_set_comparison.png)

| Target | bean_only | planning | full |
|---|---|---|---|
| Aroma | 0.01 | 0.93 | 0.93 |
| Acidity | −0.04 | 0.87 | 0.84 |
| Bitterness | 0.41 | 0.93 | 0.97 |
| Body | −0.01 | 0.99 | 1.00 |

Read this table carefully — it contains the business case.

- **Bean properties alone are worthless** for three of four dimensions (R² ≈ 0). The one exception is Bitterness, where sugar content alone gets to 0.41.
- **Adding three controllable settings recovers nearly all achievable accuracy.**
- **The 100 sensor features add almost nothing** on top of the setpoints (and for Acidity they slightly *hurt*, via added variance).

The implication is direct: **incoming bean variation is not what determines cup quality here — the roast recipe is.** Quality is therefore something the plant can control rather than something it has to accept. That is what makes an optimisation product viable.

It also means the deployable model is small. A handful of features, not a hundred. Cheaper to serve, easier to monitor, far easier to explain to a roast operator.

### 5.4 From prediction to optimisation

Prediction alone does not improve the plant. `src/optimize.py` inverts the question: given the beans we have, which settings give the best cup?

It sweeps the three levers over a grid clipped to the observed operating range (the model is never asked to extrapolate into a regime the plant has never run), scores every candidate with the planning models, and ranks by a weighted objective.

![sensitivity curves](figures/06_sensitivity_curves.png)

For an average lot (moisture 10.1, sugar 8.1, density 1.01, 2024 harvest, medium beans), the top recommendation is **11.5 min at 196.5 °C with water mist on**.

The response curves matter more than the single recommendation. They show the operator the *shape of the trade-off* — where Aroma peaks, where Bitterness starts climbing — rather than a black-box number. That is what makes the tool trustworthy on a factory floor.

**Important caveat:** the objective weights (`Aroma +1.0, Acidity +0.3, Bitterness −0.6, Body +0.8`) are placeholders I invented. Real weights must come from the cupping panel or from customer specifications. This is a business decision, not a modelling one, and it should be the first thing agreed with the customer.

A second caveat: `roast_temp_setpoint` is derived from the observed mean roasting temperature, treated as a proxy for the operator's intended setpoint. That is a modelling convenience. Before this goes anywhere near production, the plant must supply the **actual commanded setpoints** — see §6.

---

## 6. Recommended next steps

**Immediate (days)**

1. **Confirm the data is simulated.** Everything hinges on this. If it is, the accuracy figures are an artefact and must not be quoted to stakeholders.
2. **Investigate the two contradictory batches.** How were they scored twice? That answer defines the label-noise ceiling.
3. **Get the real temperature setpoints** — commanded values, not sensor readings — so the planning model rests on genuine control inputs.

**Short term (weeks)**

4. **Quantify label reliability.** Have two or three cuppers independently score ~50 batches and compute inter-rater agreement. *No accuracy target should be promised before this number exists.* If experts agree at r = 0.7, a model at R² = 0.7 is already at the ceiling.
5. **Pilot on real batches.** Fifty to a hundred genuinely measured batches will reveal more than any further work on simulated data.
6. **Agree the objective function** with the cupping panel and commercial team.

**Medium term (months)**

7. **Move from batch aggregates to roast-curve features.** Averaging a roast into five numbers per tag discards the profile shape — the ramp rate, the turning point, first crack. Real roasting quality lives in that curve. If the current sensors show no signal, this is the most likely reason.
8. **Add per-customer modelling.** There are 474 customers here; different buyers may have systematically different taste preferences.
9. Only then build the production system described in `SYSTEM_DESIGN.md`.

## 7. What I would ask the internal customer for

Ranked by expected value per unit of effort:

1. **Real production data with real expert scores.** Nothing else matters as much.
2. **Repeat cupping scores on a subset** — the label-noise ceiling.
3. **Actual control setpoints**, distinguished from realised sensor values.
4. **Full roast curves** at the current 1-minute resolution or finer, with clear batch boundaries.
5. **Bean origin, variety, processing method, supplier.** Conspicuously absent, and in real coffee these are first-order drivers of cup quality.
6. **Customer feedback, complaints and rejections.** The real business target is not a cupping score — it is whether the customer accepts the shipment. That is a label worth far more than a panel number.
7. **The definition of "good."** Which dimensions matter, for which customers, with what tolerances.
8. **Roasting equipment metadata** — machine ID, maintenance schedule, calibration history. Drift in equipment is a common hidden driver.

---

## 8. Honest limitations

- **~1,550 batches over 19 days** is a small, short sample. No seasonality, no equipment ageing, no supplier changes are observable.
- **Point predictions only.** No uncertainty intervals; a quantile or conformal approach would be more useful operationally, since an operator needs to know when the model is guessing.
- **The optimiser assumes the model is causal.** It is correlational. Acting on its recommendations changes the data-generating process — recommendations must be validated by controlled trial roasts before being trusted.
- **Objective weights are invented.** See §5.4.
- **No hyperparameter search.** Sensible defaults only. Given the accuracy ceiling is set by label quality rather than model capacity, tuning would have been effort spent in the wrong place.
