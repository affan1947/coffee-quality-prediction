"""Training entry point.

Runs the full experiment: load, clean, engineer features, compare four
estimators across three feature sets and four targets, select a winner per
target, evaluate it chronologically, and persist models, metrics and figures.

    python -m src.train
"""

from __future__ import annotations

import json
import warnings

import joblib
import pandas as pd
from sklearn.base import clone

from . import config as cfg
from . import data_loader, evaluate, features, models

warnings.filterwarnings("ignore", category=FutureWarning)

CANDIDATES = ["mean", "ridge", "random_forest", "gbm"]
SELECTION_FEATURE_SET = "full"


def run_model_comparison(train_df, test_df, model_frame) -> pd.DataFrame:
    """Score every (feature_set, target, estimator) combination."""
    rows = []
    for feature_set in features.FEATURE_SETS:
        cols = features.feature_columns(model_frame, feature_set)
        X_train, X_test = train_df[cols], test_df[cols]

        for target in cfg.TARGETS:
            y_train, y_test = train_df[target], test_df[target]

            for name, base in models.build_estimators().items():
                if name not in CANDIDATES:
                    continue
                estimator = models.wrap_for_target(clone(base), target)
                cv_mean, cv_std = evaluate.cross_validate(estimator, X_train, y_train)
                estimator.fit(X_train, y_train)
                metrics = evaluate.score(y_test, estimator.predict(X_test))
                rows.append(
                    {
                        "feature_set": feature_set,
                        "target": target,
                        "model": name,
                        "n_features": len(cols),
                        "cv_r2_mean": round(cv_mean, 4),
                        "cv_r2_std": round(cv_std, 4),
                        "test_r2": round(metrics["r2"], 4),
                        "test_mae": round(metrics["mae"], 4),
                        "test_rmse": round(metrics["rmse"], 4),
                    }
                )
                print(
                    f"  {feature_set:10s} {target:11s} {name:14s} "
                    f"cv_r2={cv_mean:6.3f}  test_r2={metrics['r2']:6.3f}  "
                    f"mae={metrics['mae']:7.3f}"
                )
    return pd.DataFrame(rows)


def fit_final_models(train_df, test_df, model_frame, comparison):
    """Refit the CV-selected best estimator per target and keep its outputs."""
    cols = features.feature_columns(model_frame, SELECTION_FEATURE_SET)
    results, importances, chosen = {}, {}, {}

    for target in cfg.TARGETS:
        subset = comparison[
            (comparison.feature_set == SELECTION_FEATURE_SET)
            & (comparison.target == target)
            & (comparison.model != "mean")
        ]
        best_name = subset.sort_values("cv_r2_mean", ascending=False).iloc[0]["model"]
        chosen[target] = best_name

        estimator = models.wrap_for_target(
            clone(models.build_estimators()[best_name]), target
        )
        estimator.fit(train_df[cols], train_df[target])
        y_pred = estimator.predict(test_df[cols])

        results[target] = {
            "model_name": best_name,
            "y_test": test_df[target].to_numpy(),
            "y_pred": y_pred,
            "metrics": evaluate.score(test_df[target], y_pred),
        }
        importances[target] = evaluate.top_importances(
            estimator, test_df[cols], test_df[target]
        )
        joblib.dump(estimator, cfg.MODEL_DIR / f"{target.lower()}_full.joblib")

        # The planning model is the deployable prescriptive artefact: every
        # input is something the plant can decide before the roast starts.
        plan_cols = features.feature_columns(model_frame, "planning")
        planner = models.wrap_for_target(
            clone(models.build_estimators()["gbm"]), target
        )
        planner.fit(train_df[plan_cols], train_df[target])
        joblib.dump(planner, cfg.MODEL_DIR / f"{target.lower()}_planning.joblib")

    joblib.dump(cols, cfg.MODEL_DIR / "feature_columns_full.joblib")
    joblib.dump(
        features.feature_columns(model_frame, "planning"),
        cfg.MODEL_DIR / "feature_columns_planning.joblib",
    )
    return results, importances, chosen


def main() -> None:
    print("Loading and cleaning data...")
    labelled, sensors, report = data_loader.load_all()
    print(report.summary(), "\n")

    print("Engineering features...")
    model_frame = features.assemble(labelled, sensors)
    n_sensor = sum("__" in c for c in model_frame.columns)
    print(f"  {n_sensor} sensor aggregate features over {len(model_frame)} batches\n")

    train_df, test_df = evaluate.chronological_split(model_frame)
    print(
        f"Chronological split: train={len(train_df)} "
        f"(to {train_df[cfg.START_TS].max():%Y-%m-%d %H:%M}), test={len(test_df)}\n"
    )

    print("Comparing estimators...")
    comparison = run_model_comparison(train_df, test_df, model_frame)
    comparison.to_csv(cfg.OUTPUT_DIR / "model_comparison.csv", index=False)

    print("\nFitting final models...")
    results, importances, chosen = fit_final_models(
        train_df, test_df, model_frame, comparison
    )

    print("\nGenerating figures...")
    evaluate.plot_target_distributions(model_frame, cfg.FIGURE_DIR / "01_target_distributions.png")
    evaluate.plot_predictions(results, cfg.FIGURE_DIR / "02_predictions.png")
    evaluate.plot_residuals(results, cfg.FIGURE_DIR / "03_residuals.png")
    evaluate.plot_importances(importances, cfg.FIGURE_DIR / "04_importances.png")

    best_rows = (
        comparison[comparison.model == "gbm"]
        .loc[:, ["feature_set", "target", "test_r2"]]
        .reset_index(drop=True)
    )
    evaluate.plot_feature_set_comparison(
        best_rows, cfg.FIGURE_DIR / "05_feature_set_comparison.png"
    )

    summary = {
        "n_batches_modelled": len(model_frame),
        "n_features_full": len(features.feature_columns(model_frame, "full")),
        "selected_model_per_target": chosen,
        "holdout_metrics": {
            t: {k: round(v, 4) for k, v in results[t]["metrics"].items()}
            for t in cfg.TARGETS
        },
        "top_features_per_target": {
            t: importances[t].head(5).round(4).to_dict() for t in cfg.TARGETS
        },
        "dropped_contradictory_batches": report.contradictory_batch_ids,
    }
    (cfg.OUTPUT_DIR / "summary.json").write_text(json.dumps(summary, indent=2))

    pd.DataFrame(
        {t: importances[t] for t in cfg.TARGETS}
    ).to_csv(cfg.OUTPUT_DIR / "feature_importances.csv")

    print("\nHold-out results")
    print("-" * 56)
    for t in cfg.TARGETS:
        m = results[t]["metrics"]
        print(f"  {t:11s} {chosen[t]:14s} R²={m['r2']:.3f}  MAE={m['mae']:7.3f}")
    print(f"\nArtefacts written to {cfg.OUTPUT_DIR} and {cfg.FIGURE_DIR}")


if __name__ == "__main__":
    main()
