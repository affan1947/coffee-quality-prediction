# End-to-End ML System Design

**Design principle:** the plant produces roughly 80 batches a day, each lasting about 12 minutes. This is a low-volume, high-value setting. It does not need a streaming platform, a feature store, or Kubernetes. It needs something a small team can run reliably and a roast operator will actually trust. Every choice below is sized to that reality — an over-engineered system that nobody maintains is worse than a simple one that runs.

---

## 1. Architecture overview

```
┌──────────────┐   ┌──────────────┐   ┌──────────────┐
│ Roaster PLC  │   │ Lab / intake │   │ Cupping panel│
│ sensors 1min │   │ bean assay   │   │ expert scores│
└──────┬───────┘   └──────┬───────┘   └──────┬───────┘
       │                  │                  │
       └────────┬─────────┴──────────────────┘
                ▼
       ┌─────────────────┐      nightly batch job
       │  Data layer     │      (Postgres + TimescaleDB)
       │  raw → curated  │      batch-level feature table
       └────────┬────────┘
                ▼
    ┌───────────┴───────────┐
    ▼                       ▼
┌─────────────┐      ┌──────────────────┐
│ Training    │      │ Inference API    │
│ pipeline    │─────▶│ FastAPI + model  │
│ (scheduled) │      │ registry         │
└──────┬──────┘      └────────┬─────────┘
       │                      │
       ▼                      ▼
┌─────────────┐      ┌──────────────────┐
│ Monitoring  │◀─────│ Operator UI      │
│ + alerting  │      │ (web, tablet)    │
└─────────────┘      └──────────────────┘
```

**Stack rationale:** Postgres with TimescaleDB (the sensor data is a time series and the plant likely already runs Postgres); FastAPI for serving (Python end-to-end, automatic OpenAPI docs); MLflow for the model registry and experiment tracking; Docker Compose on a single on-prem box, or a small managed VM. Deliberately boring, and deliberately runnable by one engineer.

**On-prem over cloud.** A roasting plant may have unreliable connectivity, and a quality-gate model that stalls because the WAN is down stops production. Local inference with asynchronous cloud sync for monitoring is the safer topology.

---

## 2. Two models, two very different deployment paths

§5.3 of the report showed that the planning feature set matches the full sensor set. That collapses the serving problem to a small, cheap model — but the two use cases still have different latency and integration requirements.

| | **Planning model** | **QC model** |
|---|---|---|
| **Inputs** | bean assay + proposed settings | + realised sensor aggregates |
| **When** | before the roast | at batch end |
| **Latency** | < 200 ms (interactive) | < 5 s (async) |
| **Consumer** | operator UI, optimiser | QC dashboard, cupping queue |
| **Business value** | prescribes the recipe | triages which batches need human cupping |

The QC model's value is not accuracy for its own sake. It is **triage**: if the model can confidently clear routine batches, the panel's limited time goes to the ambiguous ones. That is a direct labour saving, and it is measurable.

### Deployment approach

Start with **shadow mode** for at least one full production month. The model predicts every batch, predictions are logged, and nothing is acted upon. This is not caution for its own sake — it is the only way to measure real-world accuracy against real cupping scores before anyone's job depends on the output.

Then progress:

1. **Shadow** (month 1–2) — log only, compare to panel scores.
2. **Advisory** (month 3–4) — predictions shown to operators, clearly labelled as suggestions, with an easy "I disagree" button that is itself logged.
3. **Assisted triage** (month 5+) — the model routes batches to the cupping queue. A human still decides.

**Full automation is not the goal, and I would advise against proposing it.** The model recommends; the roast master decides. Beyond the trust question, that boundary is what keeps the operator engaged enough to notice when the model starts being wrong.

---

## 3. Monitoring

Three layers, because they fail differently and on different timescales.

### Layer 1 — Data quality (immediate, blocks inference)

Runs before every prediction. Cheap, catches most real incidents.

- **Schema and range checks.** Every input inside its training range. A `Roasting_Temp` of 400 °C means a broken thermocouple, not a hot roast.
- **Staleness.** A sensor reporting a constant value for 30+ minutes is stuck.
- **Completeness.** Batches average ~11.5 readings per tag. Fewer than 5 means a gap — refuse to predict rather than silently extrapolate.

**On failure the system returns "cannot predict" rather than a number.** A refused prediction is a minor inconvenience; a confident wrong one erodes trust permanently.

### Layer 2 — Drift (daily)

- **Input drift:** Population Stability Index per feature, daily against the training reference. PSI > 0.1 investigate, > 0.25 alert. Prioritise the features that actually matter — `roasting_time`, `Roasting_Temp`, `sugar_content`, `moisture`, `water_mist`. Drift in `Vacuum_Level` is noise; drift in roasting temperature is the whole model.
- **Prediction drift:** distribution of outputs versus the training distribution. This catches problems *before* labels arrive, which matters when cupping lags by days.
- **Concept drift:** the relationship shifting even when inputs look stable — equipment ageing, a new supplier, a changed panel. Detected only via labels, which is why the next layer matters.

### Layer 3 — Performance (weekly, label-dependent)

- Rolling 30-batch MAE and R² per target, per model.
- **Compared against the inter-rater agreement baseline from §6.4 of the report, not against a fixed target.** A model at R² = 0.75 when experts agree at 0.78 is performing near ceiling. Without that baseline, performance monitoring has no meaningful reference point.
- Segment by customer, bean size and harvest year — aggregate metrics hide a model that has quietly failed for one segment.
- Track the operator override rate. A rising override rate is often the earliest signal of trouble, and it arrives before the cupping scores do.

**Alerting discipline:** page a human only for data-quality failures and sustained (3+ day) performance drops. Everything else goes to a weekly digest. Alert fatigue is the standard failure mode of ML monitoring, and a system that cries wolf gets muted, which is worse than no monitoring at all.

---

## 4. Retraining

**Trigger-based, not calendar-based.** Monthly retraining on a stable process wastes effort and adds risk; a process that shifts in week two needs attention immediately.

Retrain when any of:

| Trigger | Threshold |
|---|---|
| Performance decay | rolling MAE up 20% over 30 batches |
| Input drift | PSI > 0.25 on any high-importance feature |
| New labels | 200+ newly cupped batches since last training |
| Known change | new supplier, equipment service, panel change |
| Time floor | 3 months, as a backstop |

**The pipeline is the same code that produced this analysis** — `src/train.py`, parameterised by date range. Reusing the training path for retraining is what prevents training/serving skew.

**Validation gate before any promotion.** A candidate must beat the incumbent on a chronological hold-out, show no regression on any customer segment, and pass a prediction-distribution sanity check. Promotion is automatic only if all three pass; otherwise it queues for human review.

**Rollback:** every model version, its training data snapshot and its metrics are registered in MLflow. Reverting is a config change, not a redeploy. Keep the previous two versions live-loadable.

**One caution specific to this system.** Once the optimiser influences roast settings, the training data reflects the model's own recommendations. Retraining on it creates a feedback loop that narrows the explored operating range until the model can no longer see alternatives. Mitigation: reserve ~5% of batches for deliberately randomised settings within safe bounds. It costs a little quality on those batches and it is the only thing that keeps the model honest over years.

---

## 5. User interface

Three users, three genuinely different needs. Building one interface for all three is the usual mistake.

### 5.1 Roast operator — tablet at the machine

The primary user. Likely wearing gloves, standing up, under time pressure, and not a data scientist.

```
┌──────────────────────────────────────────────┐
│  Batch B-274819      Lot #4471               │
│  ──────────────────────────────────────────  │
│  moisture 10.2   sugar 8.4   density 1.01    │
│  medium beans · 2024 harvest                 │
│                                              │
│  RECOMMENDED                                 │
│  ┌────────────────────────────────────────┐  │
│  │  11.5 min  ·  197 °C  ·  mist ON       │  │
│  └────────────────────────────────────────┘  │
│                                              │
│  Predicted    Aroma       ████████░░  149    │
│               Body        █████████░   73    │
│               Bitterness  ████░░░░░░   80    │
│               Acidity     ██░░░░░░░░   18    │
│                                              │
│  [ Accept ]  [ Adjust ▸ ]  [ Why? ]          │
└──────────────────────────────────────────────┘
```

Design decisions that matter here:

- **One recommendation, not a ranked table.** A list of five near-identical options is a decision burden, not a feature. The alternatives live behind "Adjust".
- **"Adjust" opens the sensitivity curves** from §5.4 of the report, live. Drag roasting time, watch the four bars move. This is the single most valuable screen in the system: it teaches the operator the trade-off shape and turns the model from an oracle into an instrument.
- **"Why?" shows the two or three drivers** behind the recommendation in plain language — "longer roast raises bitterness for this sugar level." Feature-importance bar charts are for the data team, not the floor.
- **Overrides are one tap and always allowed**, with an optional reason. Never block the operator. The override log is both a trust mechanism and, as noted in §3, the best early-warning signal available.

### 5.2 Quality manager — desktop dashboard

- Batch queue ranked by predicted deviation from spec, so cupping attention goes where it is needed.
- Predicted-versus-actual trend once panel scores land.
- Drift and performance panels from §3.
- Per-customer view: is quality drifting for a specific buyer?

### 5.3 Data team — MLflow plus notebooks

Experiment tracking, model registry, retraining logs, full lineage from prediction back to training snapshot. No custom UI needed; off-the-shelf tooling is sufficient and cheaper to maintain.

---

## 6. Phased delivery

Sized for a small budget, with a checkpoint before each spend.

| Phase | Duration | Output | Gate |
|---|---|---|---|
| **0. Validate** | 2 weeks | real-data check, label reliability study | *Is the signal real?* If not, stop. |
| **1. Foundation** | 4 weeks | data pipeline, batch scoring, shadow mode | measured real-world accuracy |
| **2. Advisory** | 6 weeks | operator UI, sensitivity explorer, monitoring | operator adoption and override rate |
| **3. Optimise** | 6 weeks | recommendation engine, controlled trial roasts | did quality variance actually fall? |
| **4. Scale** | ongoing | retraining automation, per-customer models | — |

**Phase 0 is a genuine stop-gate, not a formality.** If the label reliability study shows experts agreeing at r = 0.5, no model will do better, and the honest recommendation is to fix the measurement process before spending anything on machine learning. Recommending that a client *not* build the system is a legitimate outcome of this engagement, and cheaper for them than discovering it in phase 3.

---

## 7. Risks

| Risk | Likelihood | Mitigation |
|---|---|---|
| Signal is a simulation artefact | **High** | Phase 0 gate before further spend |
| Label noise caps accuracy | High | Measure inter-rater agreement first; set targets against it |
| Operators ignore the tool | Medium | Advisory-first rollout, always-available override, explain-why |
| Feedback loop narrows exploration | Medium | 5% randomised-setting batches |
| Sensor failure produces bad advice | Medium | Layer 1 checks; refuse rather than guess |
| Model treated as causal | Medium | Validate recommendations with controlled trial roasts |
| Over-engineering for 80 batches/day | Medium | Boring stack; single box; no premature platform |

---

## 8. Measuring success

Model metrics are not the business case. What the customer should hold this system to:

- **Reduction in quality variance** across batches — the core promise of process optimisation.
- **Cupping hours saved** through triage.
- **Off-spec batch rate** and customer rejection rate.
- **Operator adoption**: proportion of recommendations accepted, trending over time.

If R² improves and none of these move, the project has not delivered.
