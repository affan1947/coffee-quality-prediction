# Coffee Quality Prediction

Machine learning pipeline predicting four expert quality dimensions — Aroma, Acidity, Bitterness, Body — for a coffee roasting plant, plus a prescriptive layer that recommends roast settings for an incoming bean lot.

## Read this first

- **[REPORT.md](REPORT.md)** — Task 1: findings, model results, answers to the analysis questions.
- **[SYSTEM_DESIGN.md](SYSTEM_DESIGN.md)** — Task 2: production architecture, monitoring, retraining, UI.

## Headline results

Hold-out performance on the most recent 20% of batches (chronological split):

| Target | Model | R² | MAE |
|---|---|---|---|
| Aroma | Gradient Boosting | 0.931 | 8.76 |
| Acidity | Gradient Boosting | 0.839 | 1.22 |
| Bitterness | Ridge | 0.993 | 0.33 |
| Body | Random Forest | 0.994 | 0.90 |

**Two caveats stated up front.** These numbers are almost certainly inflated by the data being simulated — see §5.1 of the report. And the more useful finding is not the accuracy but §5.3: bean properties alone predict nothing (R² ≈ 0), while three controllable roast settings recover nearly all of it. Quality here is process-driven, and therefore actionable.

## Structure

```
coffee-quality/
├── README.md
├── REPORT.md              # Task 1 deliverable
├── SYSTEM_DESIGN.md       # Task 2 deliverable
├── data/                  # four source CSVs
├── src/
│   ├── config.py          # paths, schema, constants
│   ├── data_loader.py     # loading + cleaning with an audit trail
│   ├── features.py        # sensor windowing and aggregation
│   ├── models.py          # estimator zoo + target transforms
│   ├── evaluate.py        # validation protocol, metrics, figures
│   ├── train.py           # training entry point
│   └── optimize.py        # prescriptive roast-setting recommender
├── figures/               # six generated figures
└── outputs/
    ├── model_comparison.csv     # all 48 (feature set × target × model) runs
    ├── feature_importances.csv
    ├── summary.json
    ├── train_log.txt
    └── models/                  # persisted models + feature manifests
```

## Running it

```bash
pip install pandas numpy scikit-learn matplotlib joblib

python -m src.train      # full experiment: ~5 min, writes models + figures
python -m src.optimize   # recommend settings for an example bean lot
```

`src.train` compares 4 estimators × 4 targets × 3 feature sets, selects the best model per target by cross-validated R², refits, evaluates chronologically, and persists everything.

## Method notes

**Chronological validation, not random.** Production predicts forward in time. A random split lets the model learn from batches occurring after the ones it is scored on, which flatters the result.

**Two batches dropped for contradictory labels.** `B-781456` and `B-820426` are each scored twice with irreconcilable values. Averaging would invent a score no expert gave. Both are flagged in `outputs/summary.json` for the plant to investigate — and they are the clearest available evidence of the label-noise ceiling.

**Acidity modelled on a log1p scale.** Median 0.08, max 113.9. The transform is wrapped in `TransformedTargetRegressor` so all reported metrics stay on the original scale.

**Feature sets separated by availability.** Sensor data exists only after a roast finishes, so a model that uses it can grade a batch but cannot plan one. The `planning` set contains only inputs knowable beforehand, which is what makes the optimiser deployable.
